@extends('capas.app')

@section('title','login')
    
@section('content')
    
@endsection